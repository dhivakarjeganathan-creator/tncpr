INSERT INTO alerts.status(Node,Severity,Summary,AlertGroup,AlertKey,Identifier,Type,Region) VALUES 
('corning-vcu-0470007', 5, 'Threshold violation detected for corningcarrier_rn_stall in ruleexecutionresults. Record ID: 04700070000-0001-01, Value: 100.0, Occurrence Count: 1', 'corningcarrier_rn_stall', '04700070000-0001-01', '04700070000-0001-01', 1, 'S. California');
INSERT INTO alerts.status(Node,Severity,Summary,AlertGroup,AlertKey,Identifier,Type,Region) VALUES 
('corning-vcu-0470007', 5, 'Threshold violation detected for corningcarrier_rn_stall in ruleexecutionresults. Record ID: 04700070000-0002-01, Value: 100.0, Occurrence Count: 1', 'corningcarrier_rn_stall', '04700070000-0002-01', '04700070000-0002-01', 1, 'S. California');
